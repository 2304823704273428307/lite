-- Created on 02/17/2025
-- Table names:
AimbotStats_7 = {}
Table_4483381587_7 = {}
Teams_7 = {}
Keybinds_7 = {}
-- Properties:
AimbotStats_9["TeamAutofill"] = true

AimbotStats_9[4483381587] = Table_4483381587_9

AimbotStats_9["Keybinds"] = Keybinds_7

return AimbotStats_9